import React from 'react'
import herojpg from '../../assets/bakery.webp'
import HeroTitle from '../ui/HeroTitle'
import Paragraph from '../ui/Paragraph'
import Input from '../ui/Input'
import Button from '../ui/Button'
import Card from '../ui/Card'
import { SearchIcon, } from '../ui/Icons'
import ShoppingCart from '../ui/ShoppingCart'
import FilterNavbar from '../ui/FilterNavbar'

const Hero = () => {
  return (
    <div>
        <div className='hidden xl:flex h-[516px] w-full mx-auto items-center justify-center'>
            <div className='w-full h-full relative'>
                <img loading='lazy' className='w-full h-full object-cover' src={herojpg} alt="hero.jpg" />
                <div className='absolute top-30 left-[50%] transform-[50%] -translate-x-1/2'>
                    <HeroTitle className="text-[clamp(1.5rem,3vw,3rem)] font-bold" title="Get Your Bakery Items Delivered">
                    </HeroTitle>
                </div>
                <div className='absolute top-50 left-[50%] transform-[50%] -translate-x-1/2'>
                    <Paragraph className="text-[clamp(14px,16px,18px)] font-normal" text="Get your favorite bakery items baked and delivered to your doorsteps at any time">
                    </Paragraph>
                </div>
                <div className='absolute top-70 left-[50%] transform-[50%] -translate-x-1/2 flex'>
                    <Input name="searchbar" className=" w-[626px] h-[57px] pl-5 shadow-lg rounded-l-lg focus:outline-[#009F7F] focus:outline-1" placeHolder="Search your products from here" type="text"></Input>
                    <Button className="w-[146px] h-[57px] shadow-lg font-bold bg-[#009F7F] rounded-r-lg text-white flex items-center justify-center gap-3">
                        <span><svg width="17.05" height="18" viewBox="0 0 17.048 18"><path fill="currentColor" d="m13.024 12.707 3.225 3.218c.167.167.341.329.5.506a.894.894 0 1 1-1.286 1.238c-1.087-1.067-2.179-2.131-3.227-3.236a.924.924 0 0 0-1.325-.222A7.509 7.509 0 1 1 7.611.004a7.532 7.532 0 0 1 6 11.936c-.172.237-.356.46-.587.767m-5.537.521a5.707 5.707 0 1 0-5.675-5.72 5.675 5.675 0 0 0 5.675 5.72"/></svg></span>
                        <span>Search</span>
                    </Button>
                </div>

                <Card className="fixed right-0 top-[50%] w-[85px] h-[96px] bg-[#009F7F] rounded-l-md flex flex-col items-center justify-center gap-3 z-70">
                    <ShoppingCart text_up="0 Item" text_below="$0.00" ></ShoppingCart>
                </Card>
            </div>
        </div>

        {/* mini hero-main for lg 1024 only  */}
        <div className='hidden lg:flex xl:hidden'>
            <Card className="h-[480px] w-full bg-white flex flex-col items-center justify-center gap-5 shadow-sm z-51">
                <img className='w-full h-full relative object-cover' src={herojpg} alt="" />

                <div className='absolute top-55 w-full left-[50%] transform-[50%] -translate-x-1/2 flex flex-col items-center justify-center gap-8'>
                    <HeroTitle className="text-4xl font-bold" title="Get Your Bakery Items Delivered"></HeroTitle>
                    <Paragraph className="text-lg" text="Get your favorite bakery items baked and delivered to your doorsteps at any time" ></Paragraph>
                </div>

                <div className='flex absolute top-90 left-[50%] transform-[50%] -translate-x-1/2'>
                    <Input name="searchbar" className="w-[618px] h-[57px] pl-5 shadow-lg rounded-l-lg focus:outline-[#009F7F] focus:outline-1" placeHolder="Search your products from here"></Input>
                    <Button className="w-[144px] h-[57px] shadow-lg font-bold bg-[#009F7F] rounded-r-lg text-white flex items-center justify-center gap-3">
                        <SearchIcon className="w-5 h-5"></SearchIcon>
                        <span>Search</span>
                    </Button>
                </div>

                <Card className="fixed right-0 top-[45%] w-[85px] h-[96px] bg-[#009F7F] rounded-l-md flex flex-col items-center justify-center gap-3 z-70">
                    <ShoppingCart text_up="0 Item" text_below="$0.00" ></ShoppingCart>
                </Card>
            </Card>
        </div>

        <FilterNavbar className="hidden lg:flex xl:hidden sticky top-[85px] z-50 bg-white items-center justify-between px-4 w-full h-[56px]" />
        
    </div>
  )
}

export default Hero