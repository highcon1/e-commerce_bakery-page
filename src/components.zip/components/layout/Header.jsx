import Logo from "../../assets/Logo.webp";
import Button from '../ui/Button.jsx';
import menu from "../../data/menu.jsx";
import Card from "../ui/Card.jsx";
import { HamburgerIcon, SearchIcon } from "../ui/Icons.jsx";
import BottomNav from "./BottomNav.jsx";
import FilterNavbar from "../ui/FilterNavbar.jsx";

const Header = () => {

  return (
    <div className="sticky top-0 z-50 bg-white">
        {/* mobile first */}
        <div className="sm:hidden h-[auto] shadow-lg border-b-1 border-gray-300">
            <div className="w-full h-[112px]">
                <div className="w-full h-[56px] flex items-center justify-between shadow-gray-300 shadow-sm">
                    <img className="px-4" src={Logo} alt="Pickbazar logo.webp" />
                </div>

                <FilterNavbar className="flex items-center justify-between px-4 w-full h-[56px]" ></FilterNavbar>
            </div>
        </div>

        {/* small screen here 640 - 1024 */}
        <div className="hidden sm:block lg:hidden h-[auto] shadow-lg border-b-1 border-gray-300">
            <div className="w-full h-[112px]">
                <div className="w-full h-[56px] flex items-center justify-between shadow-gray-300 shadow-sm">
                    <div className="flex items-center justify-between ">
                        <img className="px-4" src={Logo} alt="Pickbazar logo.webp" />
                    </div>
                    <div className="px-4">
                        <a href="">
                            <Button className="w-[127px] h-[38px] rounded-md bg-[#019376] text-white font-bold text-[14px]">
                                <span>Become a Seller</span>
                            </Button>
                        </a>
                    </div>
                </div>

                <FilterNavbar className="flex items-center justify-between px-4 w-full h-[56px]" ></FilterNavbar>
            </div>
        </div>

        {/* large screen here 1024 - 1280*/}
        <div className="hidden lg:block xl:hidden">
            <div className="w-full">
                <div className="w-full h-[85px] flex items-center justify-between shadow-gray-300 shadow-sm px-7">
                    <div className="flex items-center gap-3">
                        <div>
                            <a href=""><HamburgerIcon className="w-7"></HamburgerIcon></a>
                        </div>
                        <div>
                            <img src={Logo} alt="Pickbazar logo.webp" />
                        </div>
                    </div>

                    {/* buttons on the right side*/}
                    <div className="flex items-center justify-center gap-4">
                        <a href="">
                            <Card className="h-[38px] w-[38px] rounded-full border-1 border-gray-300 flex items-center justify-center">
                                <SearchIcon className="w-4 h-4" ></SearchIcon>
                            </Card>
                        </a>

                        <a href="">
                            <Button className="w-[53px] h-[38px] rounded-md bg-[#019376] text-white font-bold text-[14px]">
                                <span>Join</span>
                            </Button>
                        </a>

                        <a href="">
                            <Button className="w-[127px] h-[38px] rounded-md bg-[#019376] text-white font-bold text-[14px]">
                                <span>Become a Seller</span>
                            </Button>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        {/* extra large screen here */}
        <div className="hidden xl:flex shadow-md container px-10 mx-auto h-[83px] items-center justify-between">
            {/* this is the logo and button section of the navbar */}
            <div className="flex items-center gap-4">
                <img src={Logo} alt="Pickbazar logo.webp" />
                <div>
                    <div className="relative">
                        <Button className="w-[152px] h-[46px] border-gray-200 text-[#009F7F] font-bold border-2 rounded-[5px] flex items-center gap-5 justify-center"> 
                            <span><svg xmlns="http://www.w3.org/2000/svg" id="Outline" viewBox="0 0 512 512" width="512" height="512" fill="currentColor" className="h-5 w-5"><path d="M213.056,231.438a8,8,0,1,0,5.888-14.876c-18.527-7.335-42.3-11.374-66.944-11.374s-48.417,4.039-66.944,11.374a8,8,0,1,0,5.888,14.876c16.7-6.61,38.382-10.25,61.056-10.25S196.357,224.828,213.056,231.438Z" fill="currentColor"></path><path d="M416,16H384c-23.366,0-43.613,25.444-58.552,73.58-7.08,22.815-12.528,49.446-16.163,78.42H144v.118c-32.288.855-62.486,6.86-85.746,17.149C31.006,197.319,16,214.135,16,232.617c0,15.891,11.317,30.777,32,42.266V422.049a65.688,65.688,0,0,0-23.435,38.717,29.684,29.684,0,0,0,6.2,24.659A28.79,28.79,0,0,0,53.047,496H346.953a28.681,28.681,0,0,0,17.852-6.229A34.1,34.1,0,0,0,384,496h32c23.366,0,43.613-25.444,58.552-73.58C488.383,377.854,496,318.751,496,256s-7.617-121.854-21.448-166.42C459.613,41.444,439.366,16,416,16ZM53.047,480a12.848,12.848,0,0,1-9.929-4.743,13.738,13.738,0,0,1-2.851-11.416,49.465,49.465,0,0,1,29.246-36.168,111.883,111.883,0,0,0-4.867,19.063A47.027,47.027,0,0,0,71.416,480ZM104,480H99.361c-4.729,0-9.3-2.31-12.859-6.5-5.263-6.195-7.531-15.233-6.067-24.177,4-24.452,16.7-44.92,33.932-56.125a86.14,86.14,0,0,0-.505,38.033l9.6,45.7a23.548,23.548,0,0,0,.886,3.067Zm18.94-108.547c-18.246,5.984-33.872,19.364-44.576,37.26A63.07,63.07,0,0,0,64,412.654V270.061a8,8,0,0,0-4.415-7.152C41.8,253.993,32,243.235,32,232.617,32,221.024,43.929,209.1,64.727,199.9,87.905,189.646,118.9,184,152,184s64.1,5.646,87.273,15.9c20.8,9.2,32.727,21.125,32.727,32.718,0,10.618-9.8,21.376-27.585,30.292A8,8,0,0,0,240,270.061v66.433a82.933,82.933,0,0,0-19.088-6.381,104.007,104.007,0,0,0-41.824,0,82.889,82.889,0,0,0-52.978,36.075C124.979,367.91,123.938,369.673,122.94,371.453Zm147.539,56.485-9.6,45.707A8.037,8.037,0,0,1,253.05,480H146.95a8.037,8.037,0,0,1-7.829-6.355l-9.6-45.707a69.688,69.688,0,0,1,9.962-52.964,66.994,66.994,0,0,1,42.8-29.184,88.1,88.1,0,0,1,35.426,0,66.994,66.994,0,0,1,42.8,29.184A69.688,69.688,0,0,1,270.479,427.938ZM313.5,473.5c-3.563,4.193-8.13,6.5-12.859,6.5H275.651a23.579,23.579,0,0,0,.886-3.066l9.6-45.706a86.14,86.14,0,0,0-.5-38.033c17.233,11.2,29.929,31.674,33.932,56.126C321.029,458.265,318.761,467.3,313.5,473.5ZM277.06,371.453c-1-1.78-2.039-3.543-3.17-5.265A84.568,84.568,0,0,0,256,346.53V274.883c20.683-11.489,32-26.375,32-42.266,0-18.482-15.006-35.3-42.254-47.35-.982-.435-2-.848-3-1.267h64.745C305.194,206.984,304,231.205,304,256c0,56.555,6.13,109.782,17.4,152.319C310.705,390.619,295.172,377.393,277.06,371.453Zm79.822,103.8A12.848,12.848,0,0,1,346.953,480H328.584a47.028,47.028,0,0,0,6.77-33.265,111.965,111.965,0,0,0-4.867-19.062,49.463,49.463,0,0,1,29.246,36.169A13.737,13.737,0,0,1,356.882,475.257ZM384,480a18.245,18.245,0,0,1-9.814-3.218,29.809,29.809,0,0,0,1.249-16.016A65.552,65.552,0,0,0,339.708,414.3a401.074,401.074,0,0,1-9.879-42.129c11.047-3.1,35.55-7.273,67.641,3.423v0a8,8,0,1,0,5.058-15.17v0l-.089-.029-.113-.035c-34.435-11.43-61.2-7.762-75.142-4.084a677.754,677.754,0,0,1-7.164-94.85c9.779-3.326,35.077-9.281,69.448,2.176v0a8,8,0,1,0,5.058-15.17v0l-.088-.028-.116-.037c-33.673-11.174-60.012-7.529-74.241-3.655a669.018,669.018,0,0,1,6.836-87.643c9.119-3,35.244-9.227,70.549,2.541v0a8,8,0,1,0,5.058-15.17v0l-.089-.029-.113-.035c-32.393-10.752-57.989-8.143-72.517-4.733a393.693,393.693,0,0,1,10.918-45.292C352.84,55.3,369.016,32,384,32s31.16,23.3,43.271,62.322C440.639,137.4,448,194.812,448,256s-7.361,118.605-20.729,161.678C415.16,456.7,398.984,480,384,480Zm75.271-62.322C447.16,456.7,430.984,480,416,480h-1.859c10.781-12.331,20.367-31.659,28.411-57.58C456.383,377.854,464,318.751,464,256s-7.617-121.854-21.448-166.42c-8.044-25.921-17.63-45.249-28.411-57.58H416c14.984,0,31.16,23.3,43.271,62.322C472.639,137.4,480,194.812,480,256S472.639,374.605,459.271,417.678Z" fill="currentColor"></path></svg></span>
                            <span>Bakery</span>
                            <span className="mt-1.5"><svg width="10" height="6" viewBox="0 0 10 6"><path d="M128,192l5,5,5-5Z" transform="translate(-128 -192)"        fill="currentColor"></path></svg></span>
                        </Button>
                    </div>

                    <div className={` absolute w-[193px] h-auto py-4 shadow-lg shadow-gray-900/50% mt-2 transition-all duration-200 ease-in-out bg-white rounded-[5px]`}>
                        {menu.map((item, index) => (
                            <div key={index} className="flex items-start">
                                <a href="" className="flex items-center gap-5 px-5 py-2 font-bold hover:text-[#009F7F]"><span>{item.svg}</span><span>{item.name}</span></a>
                            </div>)
                        )}
                    </div>
                </div>
            </div>

            {/* this is for the right hand side of the navbar -  the links and buttons */}
            <div className="flex gap-10 items-center">
                <ul className="flex gap-10">
                    <li><a href="" className="hover:text-[#009F7F]">Shops</a></li>
                    <li><a href="" className="hover:text-[#009F7F]">Offers</a></li>
                    <li><a href="" className="hover:text-[#009F7F]">Contact</a></li>
                    <div className="relative group">
                        <div>
                            <li><a href="" className="flex gap-3 hover:text-[#009F7F]"><span>Pages</span><span className="flex items-center"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 12 7.2" width="12" height="7.2"><path d="M6.002 5.03L10.539.265a.826.826 0 011.211 0 .94.94 0 010 1.275l-5.141 5.4a.827.827 0 01-1.183.026L.249 1.545a.937.937 0 010-1.275.826.826 0 011.211 0z" fill="currentColor"></path></svg></span></a></li>
                        </div>

                        <div className="absolute mt-2 opacity-0 top-full left-0 scale-95 group-hover:opacity-100 group-hover:scale-100 group-hover:visible invisible transition-all duration-300 ease-out bg-white z-50 w-[250px] h-auto rounded-b-lg shadow-lg shadow-gray-900/50%">
                            <ul className="flex flex-col gap-4 mt-1 px-5 py-7">
                                <li><a href="" className="inline-block hover:text-[#009F7F] transform transition-all duration-200 ease-in-out hover:translate-x-1 hover:scale-105">Flash Sale</a></li>
                                <li><a href="" className="inline-block hover:text-[#009F7F] transform transition-all duration-200 ease-in-out hover:translate-x-1 hover:scale-105">Manufacturers/Publishers</a></li>
                                <li><a href="" className="inline-block hover:text-[#009F7F] transform transition-all duration-200 ease-in-out hover:translate-x-1 hover:scale-105">Authors</a></li>
                                <li><a href="" className="inline-block hover:text-[#009F7F] transform transition-all duration-200 ease-in-out hover:translate-x-1 hover:scale-105">FAQ</a></li>
                                <li><a href="" className="inline-block hover:text-[#009F7F] transform transition-all duration-200 ease-in-out hover:translate-x-1 hover:scale-105">Terms & Conditions</a></li>
                                <li><a href="" className="inline-block hover:text-[#009F7F] transform transition-all duration-200 ease-in-out hover:translate-x-1 hover:scale-105">Customer Refund Policy</a></li>
                                <li><a href="" className="inline-block hover:text-[#009F7F] transform transition-all duration-200 ease-in-out hover:translate-x-1 hover:scale-105">Vendor Refund Policy</a></li>
                            </ul>
                        </div>
                    </div>
                </ul>

                <div className="flex gap-5">
                    <Button className="w-[53px] h-[38px] rounded-lg bg-[#019376] font-bold text-white text-[13px]">
                        Join
                    </Button>

                    <Button className="w-[130px] h-[38px] rounded-lg bg-[#019376] font-bold text-white text-[13px]">
                        Become a Seller
                    </Button>
                </div>
            </div>
        </div>

        {/* bottom navbar */}
        <BottomNav />
    </div>
  )
}

export default Header