import React from 'react'

const Card = ({className, children, data_catId}) => {
  return (
    <div data-catid={data_catId} className={className}>
        {children}
    </div>
  )
}

export default Card